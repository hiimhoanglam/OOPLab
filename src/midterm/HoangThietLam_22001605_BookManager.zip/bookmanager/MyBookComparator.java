package midterm.bookmanager;



public interface MyBookComparator {
    int compare(Book left, Book right);
}
