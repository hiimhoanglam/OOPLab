package midterm.bookmanager;

public interface MyBookComparable {
    int compareTo(Book another);
}
